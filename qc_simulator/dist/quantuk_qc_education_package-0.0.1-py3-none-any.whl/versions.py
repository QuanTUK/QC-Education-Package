import sys, matplotlib, numpy

print('Python: ', sys.version)
print('matplotlib: ', matplotlib.__version__)
print('Numpy: ', numpy.version.version)