import numpy as np
from qc_simulator.simulator import simulator
qc = simulator(1)

# Example adapted from