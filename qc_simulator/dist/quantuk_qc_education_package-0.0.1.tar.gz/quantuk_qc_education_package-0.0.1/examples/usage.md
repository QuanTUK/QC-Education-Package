# Useage of examples inside qc_simulator python module
In qc_simulator parent directory run e.g.

`python -m qc_simulator.examples.qc_engine.01_01_random_bit`

to run an example.

---
*This is the (pythonic) way.*