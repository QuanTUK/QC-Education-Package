# QuanTUK Quantum Computing Education Package

This is a test build for testing setups with github and google collab notebooks