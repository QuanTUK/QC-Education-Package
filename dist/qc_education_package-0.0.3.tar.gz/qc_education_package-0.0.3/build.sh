#!/bin/bash

# pip instal build bump
python3 -m build

python3 -m bump